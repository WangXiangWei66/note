#痞老板
#开发时间；

#痞老板
#开发时间；

import tkinter
import random
import threading
import time


def boom():
    window=tkinter.Tk()
    width=window.winfo_screenwidth()
    height=window.winfo_screenheight()
    a=random.randrange(0,width)
    b=random.randrange(0,height)
    window.title('你个傻狍子')
    window.geometry("100x50"+"+"+str(a)+'+'+str(b))
    tkinter.Label(window,text="你个傻狍子",bg='green',
             font=('宋体',17),height=4).pack()
    window.mainloop()


    threads=[]
    for i in range(100):
        t=threading.Thread(target=boom)
        threads.append(t)
        time.sleep(0.1)
        threads[1].start()
        print(dir(window))
if __name__=="__main__":
    while True:
        try:
            boom()

        except:
            print("逗你玩")

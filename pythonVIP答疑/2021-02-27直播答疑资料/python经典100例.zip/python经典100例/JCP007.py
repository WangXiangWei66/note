#coding:utf-8
'''
【程序7】  (在C环境中运行)
题目：输出特殊图案，请在c环境中运行，看一看，Very Beautiful!
1.程序分析：字符共有256个。不同字符，图形不一样。　　　　　　
2.程序源代码：
'''
a = 176
b = 219

print(chr(a),chr(b),chr(a),chr(b),chr(a))
print(chr(a),chr(a),chr(b),chr(a),chr(a))
print(chr(a),chr(b),chr(a),chr(b),chr(a))
print(chr(b),chr(a),chr(a),chr(a),chr(b))


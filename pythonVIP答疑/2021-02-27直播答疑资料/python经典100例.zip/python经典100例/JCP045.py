#coding:utf-8
'''
【程序45】
题目：学习使用register定义变量的方法。
1.程序分析：
2.程序源代码：
没有register关键字，用整型变量代替
'''
tmp = 0
for i in range(1,101):
    tmp += i
print ('The sum is %d' % tmp)

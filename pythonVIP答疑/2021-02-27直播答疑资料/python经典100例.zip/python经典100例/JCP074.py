#coding:utf-8
'''
【程序74】
题目：连接两个链表。
1.程序分析：
2.程序源代码：
代码上好像只有，列表排序
'''
if __name__ == '__main__':
    arr1 = (3,12,8,9,11)
    ptr = list(arr1)
    print (ptr)
    ptr.sort()
    print (ptr)

#coding:utf-8
'''
【程序23】 
题目：打印出如下图案（菱形）

   *
  ***
 *****
*******
 *****
  ***
   *
1.程序分析：先把图形分成两部分来看待，前四行一个规律，后三行一个规律，利用双重
　　　　　　for循环，第一层控制行，第二层控制列。 
2.程序源代码： 
'''

while True:
    x = int(input('请输入行数'))
    if x % 2 != 0:
        break
uprow = (x + 1) // 2  # 上半部分的行数
for i in range(1, uprow + 1):
    for j in range(1, uprow - i + 1):
        print(' ', end='')
    for j in range(1, 2 * i):
        print('*', end="")
    print()

downrow = x // 2  # 下半部分的行数
for i in range(1, downrow + 1):
    for j in range(1, i + 1):
        print(' ', end='')
    for j in range(1, 2 * (3 - i) + x - 5):
        print('*', end='')
    print()
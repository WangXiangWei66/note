#coding:utf-8
'''
【程序98】
题目：从键盘输入一个字符串，将小写字母全部转换成大写字母，然后输出到一个磁盘文件“test”中保存。
　　　输入的字符串以！结束。 
1.程序分析：
2.程序源代码：
'''
if __name__ == '__main__':
    fp = open('test.txt','w')
    string = input('please input a string:\n')
    string = string.upper()
    fp.write(string)
    fp = open('test.txt','r')
    print (fp.read())
    fp.close()

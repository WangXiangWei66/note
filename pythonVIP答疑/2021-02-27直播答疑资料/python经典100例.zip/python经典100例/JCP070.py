#coding:utf-8
'''
题目：写一个函数，求一个字符串的长度，在main函数中输入字符串，并输出其长度。　　　
1.程序分析：
2.程序源代码
就这样吧
'''
if __name__ == '__main__':
    s = input('please input a string:\n')
    print ('the string has %d characters.' % len(s))

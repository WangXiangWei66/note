# 好好学习
# 整数的ASCII码

import  pandas as pd
import  matplotlib.pyplot as plt
import  numpy as np
df=pd.read_excel('第7次人口普查.xlsx')
print(df)

plt.rcParams['font.sans-serif']=['SimHei']

y3=df['2021高考报名人数']
print(y3)
x=df['地区']
plt.xticks(rotation = 45)

plt.grid(axis='y')


plt.bar(x,y3,width=0.45)
plt.xticks(rotation = 90)



plt.show()
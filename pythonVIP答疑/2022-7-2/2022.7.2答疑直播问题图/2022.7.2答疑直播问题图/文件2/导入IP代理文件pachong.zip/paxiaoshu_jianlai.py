import requests
import re
from daili_ip import func_ip
proxies={'http':func_ip()}
print(func_ip())
headers={'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/100.0.4896.60 Safari/537.36'}
for i in range(1,100):
    response = requests.get(f'https://www.bige3.com/book/1031/{i}.html',headers=headers,proxies=proxies)
    # print(response)
    response.encoding='utf-8'
    data=response.text
    result = re.findall('<div id="chaptercontent" class=".*?">(.*?)</p></div>', data, re.S)
    print(result[0])
    contend = result[0].replace('<br /><br />', '\n')
    print(contend)
    with open('剑来.txt', mode='a', encoding='utf-8') as f:
        f.write(contend)
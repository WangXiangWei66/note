import random

import requests

import parsel
def func_ip():
    url = "https://zhimahttp.com/?utm-source=bdtg&utm-keyword=?zmpc0537"


    headers = {'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/62.0.3202.62 Safari/537.36'}

    r = requests.get(url=url,headers=headers)#requests库get方法获取HTML网页

    select = parsel.Selector(r.text)

    divs = select.css("div#ip_list tr")
    ip_list=[]
    for div in divs:
        ip_http=div.css('td:nth-child(3)::text').get()
        ip_ip=div.css('td:nth-child(1)::text').get()
        ip_port=div.css('td:nth-child(2)::text').get()
        # print(ip_http,ip_ip,ip_port)
        ip_add=(f"{ip_http}://{ip_ip}:{ip_port}")
        ip_list.append(ip_add)
    return random.choice(ip_list)

func_ip()
# print(func_ip())



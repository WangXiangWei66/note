#教育机构 ：马士兵教育
#讲    师：杨淑娟
#开发时间：2020/4/2 11:35
#任务1：定义一个圆的类计算面积和周长
class Circle():
    def __init__(self,r):
        self.r=r

    #计算圆的面积
    def get_area(self):
        return 3.14*self.r*self.r

    #计算圆的周长
    def get_perimeter(self):
        return 2*3.14*self.r

r=int(input('请输入圆的半径:'))
c=Circle(r)
print('圆的面积为:',c.get_area())
print('圆的周长为:',c.get_perimeter())

#教育机构 ：马士兵教育
#讲    师：杨淑娟
#开发时间：2020/4/3 15:28
class Student(object):
    def __init__(self,s_name,s_age,s_sex,s_python):
        self.s_name=s_name
        self.s_age=s_age
        self.s_sex=s_sex
        self.s_python=s_python
    def info(self):
        print(self.s_name,self.s_age,self.s_sex,self.s_python)

print('请输入5位学员的信息：（姓名#年龄#性别#成绩）')
lst=[]
for i in range(5):
    s=input('请输入第'+str((i+1))+'位学员的成绩:')
    s_list=s.split('#')
    stu=Student(s_list[0],int(s_list[1]),s_list[2],int(s_list[3]))
    lst.append(stu)
#遍历列表
for item in lst:
    item.info()

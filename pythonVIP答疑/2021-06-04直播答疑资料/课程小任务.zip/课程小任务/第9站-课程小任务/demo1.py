#教育机构 ：马士兵教育
#讲    师：杨淑娟
#开发时间：2020/3/29 14:07
#任务1：统计字符串中出现指定字符的次数
s='hellopython,Hellojava,hellodjango'
word=input('请输入要统计的字符:')

def get_count(s,word):
    count=0
    for item in s:
        if word.upper()==item or word.lower()==item:
            count+=1
    return count

print(word,'在',s,'中，出现的次数:',get_count(s,word))
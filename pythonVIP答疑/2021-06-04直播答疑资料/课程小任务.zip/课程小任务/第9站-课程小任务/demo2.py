#教育机构 ：马士兵教育
#讲    师：杨淑娟
#开发时间：2020/3/29 14:40
#任务2：格式化输出商品的名称和单价
lst=[['01','电风扇','美的',500],
     ['02','洗衣机','TCL',1000],
     ['03','微波炉','老板',400]]
print('编号\t\t名称\t\t\t品牌\t\t单价')
for item in lst:
    for i in item:
        print(i,end='\t\t')
    print()
print('-------格式化输出-------------')
print('编号\t\t\t名称\t\t\t品牌\t\t单价')
for item in lst:
    item[0]='0000'+item[0]
    item[3]='￥{:.2f}'.format(item[3])

for item in lst:
    for i in item:
        print(i,end='\t\t')
    print()
#教育机构 ：马士兵教育
#讲    师：杨淑娟
#开发时间：2020/3/29 17:41
#任务1：Mini计算器
def calc(a,b,op):
    if op=='+':
        return add(a,b)
    elif op=='-':
        return sub(a,b)
    elif op=='*':
        return mul(a,b)
    elif op=='/':
        if b!=0:
            return div(a,b)
        else:
            return  '除数不能为0'


def add(a,b):
    return a+b
def sub(a,b):
    return a-b
def mul(a,b):
    return a,b
def div(a,b):
    return a/b

a=int(input('请输入第一个整数:'))
b=int(input('请输入第二个整数:'))
op=input('请输入运算符:')
result=calc(a,b,op)
print(result)



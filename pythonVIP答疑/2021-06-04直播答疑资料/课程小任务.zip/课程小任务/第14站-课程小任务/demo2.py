#coding=utf-8
#教育机构 ：马士兵教育
#讲    师：杨淑娟
#开发时间：2020/4/5 15:49
#任务2：推算几天后的日期
import datetime
def inputdate():
    indate=input('请输入开始日期(20200808)后按回车:')
    indate=indate.strip()
    datester=indate[0:4]+'-'+indate[4:6]+'-'+indate[6:]
    return datetime.datetime.strptime(datester,'%Y-%m-%d')

print('-----------------推算几天后的日期-----------------')
sdate=inputdate()
in_num=int(input('请输入间隔数:'))
fdate=sdate+datetime.timedelta(days=in_num)
print('您推算的日期是:'+str(fdate))

#教育机构 ：马士兵教育
#讲    师：杨淑娟
#开发时间：2020/2/23 16:35

#任务4：预测未来子女的身高

father_height=float(input('请输入父亲的身高:'))
mother_height=float(input('请输入母亲的身高:'))
son_height=(father_height+mother_height)*0.54
print('预测子女的身高为:'+str(son_height)+'cm')

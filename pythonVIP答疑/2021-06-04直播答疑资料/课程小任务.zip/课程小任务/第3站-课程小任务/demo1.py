#教育机构 ：马士兵教育
#讲    师：杨淑娟
#开发时间：2020/2/25 15:20

#任务1：将指定的十进制数转换成二进制、八进制、十六进制
num=int(input('请输入一个十进制整数'))
#1) bin():将十进制整数转换为二进制字符串 binary的缩写
print(str(num)+'的二进制数为:'+bin(num))
#  2）oct()将十进制整数转换为八进制字符串 octal的缩写
print(str(num)+'的八进制数为:'+oct(num))
#  3)hex()将十进制整数转换为十六进制字符串 hexadecimal 的缩写
print(str(num)+'的十六进制数为:'+hex(num))


#教育机构 ：马士兵教育
#讲    师：杨淑娟
#开发时间：2020/3/6 19:45
price=1400
print('今日竞猜商品为小米扫地机器人：价格在 [1000-1500之间]')
guess_price=int(input())
if guess_price>price:
    print('大了')
elif guess_price<price:
    print('小了')
else:
    print('猜对了')
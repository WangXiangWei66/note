#coding=utf-8
#教育机构 ：马士兵教育
#讲    师：杨淑娟
#开发时间：2020/4/5 18:10
#任务2：编写程序，判断三个参数能否构成三角形
def is_triangle(a,b,c):
    #三条边不能是负数
    if a<0 or b<0 or c<0:
        raise Exception('三条边不能是负数')

    #判断是否构成三角形
    if a+b>c and a+c>b and b+c>a:
        print('三角形的边长为:a={0},b={1},c={2}'.format(a,b,c))
    else:
        raise  Exception('a={0},b={1},c={2},不能构成三角形'.format(a,b,c))

try:
    a = int(input('请输入第一条边'))
    b = int(input('请输入第二条边'))
    c = int(input('请输入第三条边'))

    # 判断是否构成三角形
    is_triangle(a, b, c)
except Exception as e:
    print(e)




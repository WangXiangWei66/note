#教育机构 ：马士兵教育
#讲    师：杨淑娟
#开发时间：2020/3/11 17:29
#任务1：‘千年虫’我来了
#原有的年份列表
year=[82,88,98,86,92,00,99]
print('原列表:',year)
#遍历列表元素索引与年份
for index ,value in enumerate(year):
    if str(value)!='0': #判断非0年份
        year[index]=int('19'+str(value))
    else:
        year[index]=int('200'+str(value)) #判断0年份

year.sort() #排序
print(year) #打印修改后的年份列表

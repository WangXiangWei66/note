#教育机构 ：马士兵教育
#讲    师：杨淑娟
#开发时间：2020/3/25 12:27
#任务1：我的咖啡馆你做主

coffee_name=('蓝山','卡布奇诺','拿铁','皇家咖啡','女王咖啡','美丽与哀愁')
print('您好！欢迎光临小喵咖啡屋')
#输出本店经营的咖啡
print('本店经营的咖啡有:')
for index,item in enumerate(coffee_name):
    print(index+1,'.',item,end='  ')
#选择你喜欢的咖啡
index=int(input('请输入您喜欢的咖啡编号:\n'))
print('您的咖啡到了[',coffee_name[index-1],']好了，请您慢用...')

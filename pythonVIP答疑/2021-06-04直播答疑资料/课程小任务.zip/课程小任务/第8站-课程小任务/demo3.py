#教育机构 ：马士兵教育
#讲    师：杨淑娟
#开发时间：2020/3/25 16:50
#任务3：模拟手机通信录
#创建空集合
phones=set({})
#录入5位朋友的姓名和手机号码
for i in range(5):
   info=input('请输入第'+str((i+1))+'个朋友的姓名与手机号码:')
   #添中到集合中
   phones.add(info)
#遍历集合
for i in phones:
    print(i)

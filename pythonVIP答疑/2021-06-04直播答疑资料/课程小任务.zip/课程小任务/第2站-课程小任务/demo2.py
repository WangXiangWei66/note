#教育机构 ：马士兵教育
#讲    师：杨淑娟
#开发时间：2020/2/23 15:52

#任务2：输出《红楼梦》中的金陵十二钗前五位
name1='林黛玉'
name2='薛宝钗'
name3='贾元春'
name4='贾探春'
name5='史湘云'
print('➊\t'+name1)
print('➋\t'+name2)
print('➌\t'+name3)
print('➍\t'+name4)
print('➎\t'+name5)
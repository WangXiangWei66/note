# coding:utf-8
book_name='Java程序设计教程'
publist='西安电子科技大学出版社'
pub_date='2019-02-02'
price=56.8
print('▶→→→→→→→→→→→→→→→→→→◀')
print('▷\t《',book_name,'》  \t\t\t◁')
print('▶\t出 版 社:',publist,'◀')
print('▷\t出版时间:',pub_date,'\t\t\t◁')
print('▶\t定    价:',price,'\t\t\t\t\t◀')
print('▷→→→→→→→→→→→→→→→→→→◁')


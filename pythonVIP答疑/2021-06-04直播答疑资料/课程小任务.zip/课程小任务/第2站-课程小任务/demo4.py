#教育机构 ：马士兵教育
#讲    师：杨淑娟
#开发时间：2020/2/23 16:35

#任务4：输出你的身体指标
height=170
weight=50.5
bmi=weight/(height+weight)
print('您的身高是:'+str(height))
print('您的体重是:'+str(weight))
print('您的BMI指数是:'+str(bmi))

#教育机构 ：马士兵教育
#讲    师：杨淑娟
#开发时间：2020/4/3 15:47
#任务2：请使用面向对象的思想，设计自定义类，描述出租车和家用轿车的信息
class Car(object):
    def __init__(self,type,no):
        self.type=type
        self.no=no
    def start(self):
        pass
    def stop(self):
        pass
class Taxi(Car):
    def __init__(self,type,no,company):
        super().__init__(type,no)
        self.company=company
    def start(self):
        print('乘客您好')
        print('我是{0}出租车公司的，我的车牌是:{1},您要去哪里?'.format(self.company,self.no))
    def stop(self):
        print('目的地到了，请您付费下车，欢迎再次乘坐')

class FamilyCar(Car):
        def __init__(self,type,no,name):
            super().__init__(type,no)
            self.name=name
        def start(self):
            print('我是{0}，我的汽车我做主'.format(self.name))
        def stop(self):
            print('目的地到了，我们去玩吧')
    #测试
taxi=Taxi('上海大众','京A88888','长城')
taxi.start()
taxi.stop()
print('-----------------------------------------')
family_car=FamilyCar('广汽丰田','京B66666','武大郎')
family_car.start()
family_car.stop()


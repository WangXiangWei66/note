#教育机构 ：马士兵教育
#讲    师：杨淑娟
#开发时间：2020/3/10 15:04
#任务3：猜数游戏
import random
ran=random.randint(1,100)

for i in range(1,11):
    num=int(input('我在心中有个1-100之间数，请你猜一猜:'))
    if num<ran:
        print('小了')
    elif num>ran:
        print('大了')
    else:
        print('恭喜你猜对了')
        break
print('您一共猜了{}次'.format(i))
if i<3:
    print('真聪明')
elif i<=7:
    print('还凑合')
else:
    print('哦，天哪!!!!')

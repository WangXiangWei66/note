#教育机构 ：马士兵教育
#讲    师：杨淑娟
#开发时间：2020/3/10 14:57
#模拟用户登录
for i in range(1,4):
    user_name=input('请输入用户名:')
    user_pwd=input('请输入密码:')
    if user_name=='admin' and user_pwd=='8888':
        print('登录成功')
        break
    else:
        print('用户名或密码不正确')
        if i<3:
            print('您还有{}次机会!!!'.format(3-i))
else:
    print('对不起，三次均输入错误，请联系后台管理员')
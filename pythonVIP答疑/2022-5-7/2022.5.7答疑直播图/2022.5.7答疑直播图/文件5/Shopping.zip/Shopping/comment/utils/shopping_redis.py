from flask_redis import FlaskRedis

# 创建redis数据库的客户端连接

redis_client = FlaskRedis()

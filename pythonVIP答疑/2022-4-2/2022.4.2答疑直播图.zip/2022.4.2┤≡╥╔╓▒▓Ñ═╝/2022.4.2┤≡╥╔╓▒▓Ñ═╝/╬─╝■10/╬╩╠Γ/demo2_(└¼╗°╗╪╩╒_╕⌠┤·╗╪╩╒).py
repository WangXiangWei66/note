import gc
import time
class TestOb(object):
    def __init__(self):
        print('我被创建了，我占用的存储空间是:%s'%hex(id(self)))

    def __del__(self):
        print('我怕马上就要被回收了')

i = 0
while i < 20:
    a = TestOb()
    b = TestOb()
    a.pro = b
    b.pro = a
    del a
    del b
    print(gc.get_threshold())
    print(gc.get_count())
    time.sleep(0.2)
    i += 1



#10.如何根据第3列大小顺序来对一个5*5矩阵排序？(考察的argsort()方法)
import numpy as np
nd = np.random.randint(0,30,size = (5,5))
print(nd)
# 获取第三列，并且获取第三列索引的顺序
index = nd[:,2].argsort()   #argsort():返加升序之后的数组值为从小到大的，索引值逗号之前表示行，逗号后表示列
print('-'*80)
print('第三列索引:',index)
print('-'*80)
# 根据第三列的索引顺序，对nd进行排序
# 花式索引
print(nd[index])